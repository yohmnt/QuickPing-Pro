package com.example.quickping

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.*

data class SavedHost(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val address: String,
    val group: String = "General",
    val tcpPort: Int? = null,
    val status: PingStatus = PingStatus.IDLE,
    val latencyMs: Double? = null,
    val lastChecked: String = "Tap to ping",
    val isContinuous: Boolean = false,
    val sentCount: Int = 0,
    val successCount: Int = 0,
    val minMs: Double? = null,
    val maxMs: Double? = null,
    val sumMs: Double = 0.0,
    val latencyHistory: List<Float> = emptyList()
)

enum class PingStatus {
    IDLE, PINGING, ONLINE, OFFLINE
}

data class NetworkSummary(
    val connectionType: String,
    val localIp: String,
    val gatewayIp: String,
    val subnetPrefix: String
)

data class DiscoveredDevice(
    val ip: String,
    val hostname: String,
    val latencyMs: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    QuickPingProApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickPingProApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var hostList by remember { mutableStateOf(loadHosts(context)) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedGroup by remember { mutableStateOf("All") }

    // Settings
    var pingIntervalMs by remember { mutableLongStateOf(1000L) }
    var pingTimeoutSec by remember { mutableIntStateOf(2) }
    var alertOnDrop by remember { mutableStateOf(true) }

    // Dialog States
    var editingHost by remember { mutableStateOf<SavedHost?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showScannerDialog by remember { mutableStateOf(false) }
    var showToolsDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }

    var netInfo by remember { mutableStateOf(getNetworkSummary(context)) }
    val continuousJobs = remember { mutableStateMapOf<String, Job>() }

    DisposableEffect(Unit) {
        onDispose {
            continuousJobs.values.forEach { it.cancel() }
            continuousJobs.clear()
        }
    }

    suspend fun runPingIteration(host: SavedHost, isLoop: Boolean) {
        if (!isLoop) {
            hostList = hostList.map {
                if (it.id == host.id) it.copy(status = PingStatus.PINGING, lastChecked = "Pinging...") else it
            }
        }

        val result = if (host.tcpPort != null && host.tcpPort > 0) {
            executeTcpPing(host.address, host.tcpPort, pingTimeoutSec * 1000)
        } else {
            executeIcmpPing(host.address, pingTimeoutSec)
        }

        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        hostList = hostList.map { item ->
            if (item.id == host.id) {
                val wasOnline = item.status == PingStatus.ONLINE
                val isNowOnline = result.first
                if (alertOnDrop && wasOnline && !isNowOnline) {
                    triggerDropAlert(context)
                }

                val newSent = item.sentCount + 1
                val newSuccess = if (isNowOnline) item.successCount + 1 else item.successCount
                val lossPct = (((newSent - newSuccess) * 100.0) / newSent).toInt()
                val lat = result.second

                val newMin = if (lat != null) minOf(item.minMs ?: lat, lat) else item.minMs
                val newMax = if (lat != null) maxOf(item.maxMs ?: lat, lat) else item.maxMs
                val newSum = if (lat != null) item.sumMs + lat else item.sumMs
                val avgStr = if (newSuccess > 0) String.format(Locale.US, "%.1f", newSum / newSuccess) else "-"

                val point = if (isNowOnline && lat != null) lat.toFloat() else 0f
                val updatedHistory = (item.latencyHistory + point).takeLast(25)

                val statsText = if (item.isContinuous || newSent > 1) {
                    val minMaxAvg = if (newMin != null && newMax != null) {
                        " | Min/Avg/Max: ${String.format(Locale.US, "%.1f", newMin)}/$avgStr/${String.format(Locale.US, "%.1f", newMax)}ms"
                    } else ""
                    "$timestamp | Sent: $newSent, Loss: $lossPct%$minMaxAvg"
                } else {
                    val modeTag = if (item.tcpPort != null) "TCP:${item.tcpPort}" else "ICMP"
                    "$modeTag checked at $timestamp"
                }

                item.copy(
                    status = if (isNowOnline) PingStatus.ONLINE else PingStatus.OFFLINE,
                    latencyMs = lat,
                    lastChecked = statsText,
                    sentCount = newSent,
                    successCount = newSuccess,
                    minMs = newMin,
                    maxMs = newMax,
                    sumMs = newSum,
                    latencyHistory = updatedHistory
                )
            } else item
        }
    }

    fun pingSingleHost(host: SavedHost) {
        scope.launch {
            runPingIteration(host, isLoop = false)
        }
    }

    fun toggleContinuousPing(host: SavedHost) {
        val existingJob = continuousJobs[host.id]
        if (existingJob != null && existingJob.isActive) {
            existingJob.cancel()
            continuousJobs.remove(host.id)
            hostList = hostList.map {
                if (it.id == host.id) it.copy(isContinuous = false) else it
            }
        } else {
            hostList = hostList.map {
                if (it.id == host.id) {
                    it.copy(
                        isContinuous = true,
                        sentCount = 0,
                        successCount = 0,
                        minMs = null,
                        maxMs = null,
                        sumMs = 0.0,
                        latencyHistory = emptyList(),
                        lastChecked = "Starting continuous ping..."
                    )
                } else it
            }
            val job = scope.launch {
                while (isActive) {
                    val currentHost = hostList.find { it.id == host.id } ?: break
                    runPingIteration(currentHost, isLoop = true)
                    delay(pingIntervalMs)
                }
            }
            continuousJobs[host.id] = job
        }
    }

    val groups = remember(hostList) {
        listOf("All") + hostList.map { it.group.ifBlank { "General" } }.distinct().sorted()
    }

    val filteredHosts = remember(hostList, searchQuery, selectedGroup) {
        hostList.filter { host ->
            val matchesGroup = selectedGroup == "All" || host.group.equals(selectedGroup, ignoreCase = true)
            val matchesQuery = searchQuery.isBlank() ||
                host.label.contains(searchQuery, ignoreCase = true) ||
                host.address.contains(searchQuery, ignoreCase = true) ||
                (host.tcpPort?.toString()?.contains(searchQuery) == true)
            matchesGroup && matchesQuery
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("QuickPing Pro", fontWeight = FontWeight.Bold) },
                actions = {
                    if (continuousJobs.isNotEmpty()) {
                        IconButton(onClick = {
                            continuousJobs.values.forEach { it.cancel() }
                            continuousJobs.clear()
                            hostList = hostList.map { it.copy(isContinuous = false) }
                        }) {
                            Icon(Icons.Default.Stop, contentDescription = "Stop All", tint = Color(0xFFF44336))
                        }
                    }
                    IconButton(onClick = {
                        filteredHosts.forEach { pingSingleHost(it) }
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Ping All")
                    }
                    IconButton(onClick = {
                        netInfo = getNetworkSummary(context)
                        showScannerDialog = true
                    }) {
                        Icon(Icons.Default.Radar, contentDescription = "Subnet Scanner")
                    }
                    IconButton(onClick = { showToolsDialog = true }) {
                        Icon(Icons.Default.Build, contentDescription = "Port & DNS Tools")
                    }
                    IconButton(onClick = { showBackupDialog = true }) {
                        Icon(Icons.Default.ImportExport, contentDescription = "Backup / Restore")
                    }
                    IconButton(onClick = { showSettingsDialog = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                editingHost = null
                showAddDialog = true
            }) {
                Icon(Icons.Default.Add, contentDescription = "Add Host")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Network Banner
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = MaterialTheme.shapes.medium
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${netInfo.connectionType} • IP: ${netInfo.localIp}",
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Gateway: ${netInfo.gatewayIp}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(
                        onClick = {
                            netInfo = getNetworkSummary(context)
                            if (netInfo.gatewayIp != "Unknown") {
                                scope.launch {
                                    val res = executeIcmpPing(netInfo.gatewayIp, pingTimeoutSec)
                                    val msg = if (res.first) "Gateway reachable (${res.second} ms)" else "Gateway timeout"
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    ) {
                        Text("Ping GW")
                    }
                }
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                placeholder = { Text("Search name, IP, or port...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true
            )

            // Group Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                groups.forEach { grp ->
                    FilterChip(
                        selected = selectedGroup == grp,
                        onClick = { selectedGroup = grp },
                        label = { Text(grp) }
                    )
                }
            }

            // Host List
            if (filteredHosts.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No matching hosts.
Tap + to add an IP/port or use Subnet Scanner.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredHosts, key = { it.id }) { host ->
                        HostCard(
                            host = host,
                            onTap = { pingSingleHost(host) },
                            onToggleContinuous = { toggleContinuousPing(host) },
                            onEdit = {
                                editingHost = host
                                showAddDialog = true
                            },
                            onDelete = {
                                continuousJobs[host.id]?.cancel()
                                continuousJobs.remove(host.id)
                                hostList = hostList.filterNot { it.id == host.id }
                                saveHosts(context, hostList)
                            }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }

        if (showAddDialog) {
            HostEditorDialog(
                existingHost = editingHost,
                onDismiss = { showAddDialog = false },
                onSave = { label, ip, group, port ->
                    val updated = if (editingHost != null) {
                        hostList.map {
                            if (it.id == editingHost!!.id) {
                                it.copy(
                                    label = label,
                                    address = ip,
                                    group = group,
                                    tcpPort = port,
                                    status = PingStatus.IDLE,
                                    latencyHistory = emptyList()
                                )
                            } else it
                        }
                    } else {
                        hostList + SavedHost(label = label, address = ip, group = group, tcpPort = port)
                    }
                    hostList = updated
                    saveHosts(context, updated)
                    showAddDialog = false
                }
            )
        }

        if (showScannerDialog) {
            SubnetScannerDialog(
                subnetPrefix = netInfo.subnetPrefix,
                onDismiss = { showScannerDialog = false },
                onAddDevice = { dev ->
                    if (hostList.none { it.address == dev.ip && it.tcpPort == null }) {
                        val updated = hostList + SavedHost(
                            label = dev.hostname.ifBlank { "Device ${dev.ip}" },
                            address = dev.ip,
                            group = "Discovered"
                        )
                        hostList = updated
                        saveHosts(context, updated)
                        Toast.makeText(context, "Added ${dev.ip}", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        if (showToolsDialog) {
            NetworkToolsDialog(onDismiss = { showToolsDialog = false })
        }

        if (showSettingsDialog) {
            SettingsDialog(
                intervalMs = pingIntervalMs,
                timeoutSec = pingTimeoutSec,
                alertOnDrop = alertOnDrop,
                onDismiss = { showSettingsDialog = false },
                onApply = { newInt, newTimeout, newAlert ->
                    pingIntervalMs = newInt
                    pingTimeoutSec = newTimeout
                    alertOnDrop = newAlert
                    showSettingsDialog = false
                }
            )
        }

        if (showBackupDialog) {
            BackupRestoreDialog(
                hosts = hostList,
                onDismiss = { showBackupDialog = false },
                onImport = { imported ->
                    hostList = imported
                    saveHosts(context, imported)
                    showBackupDialog = false
                    Toast.makeText(context, "Imported ${imported.size} hosts", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun HostCard(
    host: SavedHost,
    onTap: () -> Unit,
    onToggleContinuous: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val statusColor = when (host.status) {
        PingStatus.ONLINE -> Color(0xFF4CAF50)
        PingStatus.OFFLINE -> Color(0xFFF44336)
        PingStatus.PINGING -> Color(0xFFFFC107)
        PingStatus.IDLE -> MaterialTheme.colorScheme.outline
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onTap() },
        colors = CardDefaults.cardColors(
            containerColor = if (host.isContinuous) {
                MaterialTheme.colorScheme.secondaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = host.label,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                            shape = MaterialTheme.shapes.extraSmall
                        ) {
                            Text(
                                text = host.group,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    val targetText = if (host.tcpPort != null) "${host.address}:${host.tcpPort} (TCP)" else "${host.address} (ICMP)"
                    Text(
                        text = targetText,
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = host.lastChecked,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    when (host.status) {
                        PingStatus.PINGING -> {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        }
                        PingStatus.ONLINE -> {
                            val msFormatted = host.latencyMs?.let { String.format(Locale.US, "%.1f ms", it) } ?: "OK"
                            Text(
                                text = msFormatted,
                                color = statusColor,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        PingStatus.OFFLINE -> {
                            Text(
                                text = "TIMEOUT",
                                color = statusColor,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        PingStatus.IDLE -> {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Ping", tint = statusColor)
                        }
                    }

                    IconButton(onClick = onToggleContinuous) {
                        Icon(
                            imageVector = if (host.isContinuous) Icons.Default.Stop else Icons.Default.Repeat,
                            contentDescription = "Continuous Ping",
                            tint = if (host.isContinuous) Color(0xFFF44336) else MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(onClick = onEdit) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(onClick = onDelete) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (host.latencyHistory.size >= 2) {
                Spacer(modifier = Modifier.height(6.dp))
                LatencySparkline(
                    points = host.latencyHistory,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(26.dp)
                )
            }
        }
    }
}

@Composable
fun LatencySparkline(points: List<Float>, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        if (points.size < 2) return@Canvas
        val maxVal = (points.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val stepX = size.width / (points.size - 1)
        val path = Path()

        points.forEachIndexed { idx, value ->
            val x = idx * stepX
            val normalized = (value / maxVal).coerceIn(0f, 1f)
            val y = size.height - (normalized * (size.height - 4.dp.toPx())) - 2.dp.toPx()
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)

            drawCircle(
                color = if (value > 0f) Color(0xFF4CAF50) else Color(0xFFF44336),
                radius = 2.5.dp.toPx(),
                center = Offset(x, y)
            )
        }

        drawPath(
            path = path,
            color = Color(0xFF81C784),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}

@Composable
fun HostEditorDialog(
    existingHost: SavedHost?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Int?) -> Unit
) {
    var label by remember { mutableStateOf(existingHost?.label ?: "") }
    var ip by remember { mutableStateOf(existingHost?.address ?: "") }
    var group by remember { mutableStateOf(existingHost?.group ?: "General") }
    var portText by remember { mutableStateOf(existingHost?.tcpPort?.toString() ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existingHost != null) "Edit Host" else "Add Host / Port") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Name (e.g., Core Switch, DC01, RDP)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = ip,
                    onValueChange = { ip = it },
                    label = { Text("IP Address or Hostname") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = group,
                    onValueChange = { group = it },
                    label = { Text("Group / Tag (e.g., Switches, Servers, POS)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = portText,
                    onValueChange = { portText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("TCP Port (Optional: e.g., 22, 80, 443, 3389)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val cleanIp = ip.trim()
                if (cleanIp.isNotEmpty()) {
                    val finalLabel = label.trim().ifEmpty { cleanIp }
                    val finalGroup = group.trim().ifEmpty { "General" }
                    val port = portText.toIntOrNull()?.takeIf { it in 1..65535 }
                    onSave(finalLabel, cleanIp, finalGroup, port)
                }
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun SubnetScannerDialog(
    subnetPrefix: String,
    onDismiss: () -> Unit,
    onAddDevice: (DiscoveredDevice) -> Unit
) {
    val scope = rememberCoroutineScope()
    var prefix by remember { mutableStateOf(subnetPrefix) }
    var isScanning by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    val discovered = remember { mutableStateListOf<DiscoveredDevice>() }
    var scanJob by remember { mutableStateOf<Job?>(null) }

    DisposableEffect(Unit) {
        onDispose { scanJob?.cancel() }
    }

    AlertDialog(
        onDismissRequest = {
            scanJob?.cancel()
            onDismiss()
        },
        title = { Text("Local Subnet Scanner") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = prefix,
                        onValueChange = { prefix = it },
                        label = { Text("Subnet Prefix (e.g., 192.168.1)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (isScanning) {
                                scanJob?.cancel()
                                isScanning = false
                            } else {
                                discovered.clear()
                                progress = 0f
                                isScanning = true
                                scanJob = scope.launch(Dispatchers.IO) {
                                    val cleanPrefix = prefix.trim().trimEnd('.')
                                    var completed = 0
                                    val chunks = (1..254).chunked(32)
                                    for (chunk in chunks) {
                                        if (!isActive) break
                                        chunk.map { hostNum ->
                                            async {
                                                val targetIp = "$cleanPrefix.$hostNum"
                                                val res = executeIcmpPing(targetIp, 1)
                                                if (res.first) {
                                                    val hostName = try {
                                                        val addr = InetAddress.getByName(targetIp)
                                                        val canonical = addr.canonicalHostName
                                                        if (canonical != targetIp) canonical else ""
                                                    } catch (_: Exception) {
                                                        ""
                                                    }
                                                    val msText = res.second?.let { String.format(Locale.US, "%.1f ms", it) } ?: "Online"
                                                    withContext(Dispatchers.Main) {
                                                        discovered.add(DiscoveredDevice(targetIp, hostName, msText))
                                                        discovered.sortBy { it.ip.substringAfterLast('.').toIntOrNull() ?: 0 }
                                                    }
                                                }
                                                completed++
                                                withContext(Dispatchers.Main) {
                                                    progress = completed / 254f
                                                }
                                            }
                                        }.awaitAll()
                                    }
                                    withContext(Dispatchers.Main) {
                                        isScanning = false
                                    }
                                }
                            }
                        }
                    ) {
                        Text(if (isScanning) "Stop" else "Scan")
                    }
                }

                if (isScanning) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                }

                Text(
                    text = "Found ${discovered.size} active hosts:",
                    style = MaterialTheme.typography.labelMedium
                )

                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(discovered, key = { it.ip }) { dev ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = MaterialTheme.shapes.small
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(dev.ip, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                    if (dev.hostname.isNotEmpty()) {
                                        Text(dev.hostname, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                                Text(
                                    dev.latencyMs,
                                    color = Color(0xFF4CAF50),
                                    fontFamily = FontFamily.Monospace,
                                    style = MaterialTheme.typography.labelSmall
                                )
                                IconButton(onClick = { onAddDevice(dev) }) {
                                    Icon(Icons.Default.AddCircle, contentDescription = "Save Host")
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scanJob?.cancel()
                onDismiss()
            }) { Text("Close") }
        }
    )
}

@Composable
fun NetworkToolsDialog(onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var target by remember { mutableStateOf("8.8.8.8") }
    var outputLog by remember { mutableStateOf("Enter an IP or domain and run DNS Lookup or Common Port Scan.") }
    var isRunning by remember { mutableStateOf(false) }

    val commonPorts = listOf(
        21 to "FTP",
        22 to "SSH",
        23 to "Telnet",
        53 to "DNS",
        80 to "HTTP",
        443 to "HTTPS",
        445 to "SMB",
        1433 to "MSSQL",
        3389 to "RDP",
        8080 to "HTTP-Alt"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("DNS Lookup & Port Scanner") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = target,
                    onValueChange = { target = it },
                    label = { Text("Target IP or Domain") },
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        enabled = !isRunning,
                        onClick = {
                            isRunning = true
                            outputLog = "Resolving DNS for $target..."
                            scope.launch(Dispatchers.IO) {
                                val result = try {
                                    val addresses = InetAddress.getAllByName(target.trim())
                                    addresses.joinToString("
") { "${it.hostName} -> ${it.hostAddress}" }
                                } catch (e: Exception) {
                                    "DNS lookup failed: ${e.message}"
                                }
                                withContext(Dispatchers.Main) {
                                    outputLog = result
                                    isRunning = false
                                }
                            }
                        }
                    ) {
                        Text("DNS Lookup")
                    }

                    Button(
                        enabled = !isRunning,
                        onClick = {
                            isRunning = true
                            outputLog = "Scanning common TCP ports on $target..."
                            scope.launch(Dispatchers.IO) {
                                val cleanTarget = target.trim()
                                val lines = commonPorts.map { (port, service) ->
                                    async {
                                        val res = executeTcpPing(cleanTarget, port, 1200)
                                        if (res.first) {
                                            "OPEN   $port ($service) - ${String.format(Locale.US, "%.1f", res.second)} ms"
                                        } else {
                                            "CLOSED $port ($service)"
                                        }
                                    }
                                }.awaitAll()
                                withContext(Dispatchers.Main) {
                                    outputLog = lines.joinToString("
")
                                    isRunning = false
                                }
                            }
                        }
                    ) {
                        Text("Scan Ports")
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 220.dp)
                ) {
                    Text(
                        text = outputLog,
                        modifier = Modifier.padding(10.dp),
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun SettingsDialog(
    intervalMs: Long,
    timeoutSec: Int,
    alertOnDrop: Boolean,
    onDismiss: () -> Unit,
    onApply: (Long, Int, Boolean) -> Unit
) {
    var selectedInterval by remember { mutableLongStateOf(intervalMs) }
    var selectedTimeout by remember { mutableIntStateOf(timeoutSec) }
    var dropAlert by remember { mutableStateOf(alertOnDrop) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ping Settings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Continuous Ping Interval:", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(500L to "0.5s", 1000L to "1s", 2000L to "2s", 5000L to "5s").forEach { (ms, label) ->
                        FilterChip(
                            selected = selectedInterval == ms,
                            onClick = { selectedInterval = ms },
                            label = { Text(label) }
                        )
                    }
                }

                Text("Packet Timeout:", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "1s", 2 to "2s", 3 to "3s", 5 to "5s").forEach { (sec, label) ->
                        FilterChip(
                            selected = selectedTimeout == sec,
                            onClick = { selectedTimeout = sec },
                            label = { Text(label) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Vibrate/Beep when host goes offline")
                    Switch(checked = dropAlert, onCheckedChange = { dropAlert = it })
                }
            }
        },
        confirmButton = {
            Button(onClick = { onApply(selectedInterval, selectedTimeout, dropAlert) }) {
                Text("Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun BackupRestoreDialog(
    hosts: List<SavedHost>,
    onDismiss: () -> Unit,
    onImport: (List<SavedHost>) -> Unit
) {
    val context = LocalContext.current
    var jsonText by remember { mutableStateOf(serializeHostsToJson(hosts)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export / Import Host List") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Copy this JSON to back up your hosts, or paste JSON here to restore:",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = jsonText,
                    onValueChange = { jsonText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("QuickPing Hosts", jsonText))
                        Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                    }) {
                        Text("Copy JSON")
                    }
                    Button(onClick = {
                        val parsed = parseHostsFromJson(jsonText)
                        if (parsed != null) {
                            onImport(parsed)
                        } else {
                            Toast.makeText(context, "Invalid JSON format", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Text("Restore JSON")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

// --- Networking & System Helpers ---

suspend fun executeIcmpPing(host: String, timeoutSec: Int): Pair<Boolean, Double?> = withContext(Dispatchers.IO) {
    try {
        val sanitized = host.replace(Regex("[^a-zA-Z0-9.:-]"), "")
        val process = ProcessBuilder("/system/bin/ping", "-c", "1", "-W", timeoutSec.toString(), sanitized)
            .redirectErrorStream(true)
            .start()

        val reader = BufferedReader(InputStreamReader(process.inputStream))
        val output = StringBuilder()
        var line: String?
        while (reader.readLine().also { line = it } != null) {
            output.append(line).append("
")
        }

        val exitCode = process.waitFor()
        if (exitCode == 0) {
            val regex = Regex("time=([0-9.]+)\s*ms")
            val match = regex.find(output.toString())
            val ms = match?.groupValues?.get(1)?.toDoubleOrNull()
            Pair(true, ms)
        } else {
            Pair(false, null)
        }
    } catch (_: Exception) {
        Pair(false, null)
    }
}

suspend fun executeTcpPing(host: String, port: Int, timeoutMs: Int): Pair<Boolean, Double?> = withContext(Dispatchers.IO) {
    try {
        val sanitized = host.replace(Regex("[^a-zA-Z0-9.:-]"), "")
        val startNs = System.nanoTime()
        Socket().use { socket ->
            socket.connect(InetSocketAddress(sanitized, port), timeoutMs)
        }
        val elapsedMs = (System.nanoTime() - startNs) / 1_000_000.0
        Pair(true, elapsedMs)
    } catch (_: Exception) {
        Pair(false, null)
    }
}

fun getNetworkSummary(context: Context): NetworkSummary {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val activeNetwork = cm.activeNetwork
    val caps = cm.getNetworkCapabilities(activeNetwork)
    val linkProps: LinkProperties? = cm.getLinkProperties(activeNetwork)

    val connType = when {
        caps == null -> "Offline"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        else -> "Connected"
    }

    var localIp = "Unavailable"
    linkProps?.linkAddresses?.forEach { linkAddr ->
        val addr = linkAddr.address
        if (addr is Inet4Address && !addr.isLoopbackAddress) {
            localIp = addr.hostAddress ?: localIp
        }
    }

    if (localIp == "Unavailable") {
        try {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
                ni.inetAddresses?.toList()?.forEach { addr ->
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        localIp = addr.hostAddress ?: localIp
                    }
                }
            }
        } catch (_: Exception) { }
    }

    var gatewayIp = "Unknown"
    linkProps?.routes?.forEach { route ->
        if (route.isDefaultRoute && route.gateway is Inet4Address) {
            gatewayIp = route.gateway?.hostAddress ?: gatewayIp
        }
    }

    val prefix = if (localIp.count { it == '.' } == 3) {
        localIp.substringBeforeLast('.')
    } else if (gatewayIp.count { it == '.' } == 3) {
        gatewayIp.substringBeforeLast('.')
    } else {
        "192.168.1"
    }

    return NetworkSummary(connType, localIp, gatewayIp, prefix)
}

fun triggerDropAlert(context: Context) {
    try {
        val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
        toneGen.startTone(ToneGenerator.TONE_PROP_NACK, 200)
    } catch (_: Exception) { }

    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(250)
            }
        }
    } catch (_: Exception) { }
}

fun serializeHostsToJson(hosts: List<SavedHost>): String {
    val jsonArray = JSONArray()
    hosts.forEach {
        val obj = JSONObject().apply {
            put("id", it.id)
            put("label", it.label)
            put("address", it.address)
            put("group", it.group)
            if (it.tcpPort != null) put("tcpPort", it.tcpPort)
        }
        jsonArray.put(obj)
    }
    return jsonArray.toString(2)
}

fun parseHostsFromJson(raw: String): List<SavedHost>? {
    return try {
        val list = mutableListOf<SavedHost>()
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                SavedHost(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    label = obj.getString("label"),
                    address = obj.getString("address"),
                    group = obj.optString("group", "General"),
                    tcpPort = if (obj.has("tcpPort") && !obj.isNull("tcpPort")) obj.getInt("tcpPort") else null
                )
            )
        }
        list
    } catch (_: Exception) {
        null
    }
}

fun saveHosts(context: Context, hosts: List<SavedHost>) {
    val prefs = context.getSharedPreferences("quick_ping_prefs", Context.MODE_PRIVATE)
    prefs.edit().putString("saved_hosts_v3", serializeHostsToJson(hosts)).apply()
}

fun loadHosts(context: Context): List<SavedHost> {
    val prefs = context.getSharedPreferences("quick_ping_prefs", Context.MODE_PRIVATE)
    val raw = prefs.getString("saved_hosts_v3", null) ?: return defaultHosts()
    return parseHostsFromJson(raw) ?: defaultHosts()
}

fun defaultHosts() = listOf(
    SavedHost(label = "Default Gateway", address = "192.168.1.1", group = "Network"),
    SavedHost(label = "Cloudflare DNS", address = "1.1.1.1", group = "Internet"),
    SavedHost(label = "Google DNS", address = "8.8.8.8", group = "Internet"),
    SavedHost(label = "RDP Server Check", address = "192.168.1.10", group = "Servers", tcpPort = 3389)
)
